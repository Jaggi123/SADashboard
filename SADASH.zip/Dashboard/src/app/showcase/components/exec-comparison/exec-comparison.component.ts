import { Component, OnInit } from '@angular/core';
import { Chart } from 'angular-highcharts';

@Component({
  selector: 'app-exec-comparison',
  templateUrl: './exec-comparison.component.html',
  styleUrls: ['./exec-comparison.component.css']
})
export class ExecComparisonComponent{

  
    chart = new Chart({

    chart: {
      
      type: 'column'
  },

  title: {
    text: 'Sprint Details'
  },

  subtitle: {
    text: 'Sprint wise Automation details'
  },

  legend: {
    align: 'right',
    verticalAlign: 'middle',
    layout: 'vertical'
  },

  xAxis: {
    categories: ['WSAW2020S1', 'WSAW2020S2', 'WSAW2040S1'],
    labels: {
      x: -10
    }
  },

  yAxis: {
    allowDecimals: false,
    title: {
      text: 'Sprint wise'
    }
  },

  series: [{
    name: 'Pass',
    data: [500, 700, 600]
  }, {
    name: 'Fail',
    data: [100, 100, 200]
  }, {
    name: 'No Run',
    data: [200, 100, 100]
  }]

  });
}