import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExecComparisonComponent } from './exec-comparison.component';

describe('ExecComparisonComponent', () => {
  let component: ExecComparisonComponent;
  let fixture: ComponentFixture<ExecComparisonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExecComparisonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExecComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
