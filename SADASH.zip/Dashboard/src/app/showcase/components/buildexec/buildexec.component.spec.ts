import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildexecComponent } from './buildexec.component';

describe('BuildexecComponent', () => {
  let component: BuildexecComponent;
  let fixture: ComponentFixture<BuildexecComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildexecComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildexecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
