import { Component, OnInit } from '@angular/core';
import { Chart } from 'angular-highcharts';

@Component({
  selector: 'app-buildexec',
  templateUrl: './buildexec.component.html',
  styleUrls: ['./buildexec.component.css']
})
export class BuildexecComponent {
  

  chart = new Chart({
    chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'pie'
  },
  title: {
    text: 'WSAW2040S3'
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>: {point.percentage:.1f} %',
        style: {
          color:  'black'
        },
        connectorColor: 'silver'
      }
    }
  },
  series: [{
    name: 'Execution',
    data: [
      { name: 'Pass', y: 30 },
      { name: 'Fail', y: 15 },
      { name: 'No Run', y: 5 }
    ]
  }]
  });

}
