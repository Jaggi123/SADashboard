import { Component, OnInit } from '@angular/core';
import {Chart} from 'angular-highcharts';

@Component({
  selector: 'app-modulewise',
  templateUrl: './modulewise.component.html',
  styleUrls: ['./modulewise.component.css']
})
export class ModulewiseComponent {

  chart = new Chart({
    chart: {
      type: 'column'
  },
  title: {
    text: 'Modules'
  },
  xAxis: {
    categories: ['M1', 'M2', 'M3', 'M4', 'M5']
  },
  yAxis: {
    min: 0,
    title: {
      text: 'Module wise execution'
    },
    stackLabels: {
      enabled: true,
      style: {
        fontWeight: 'bold',
        color: 'gray'
      }
    }
  },
  legend: {
    align: 'right',
    x: -30,
    verticalAlign: 'top',
    y: 25,
    floating: true,
    backgroundColor:  'white',
    borderColor: '#CCC',
    borderWidth: 1,
    shadow: false
  },
  tooltip: {
    headerFormat: '<b>{point.x}</b><br/>',
    pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
  },
  plotOptions: {
    column: {
      stacking: 'normal',
      dataLabels: {
        enabled: true,
        color:  'white'
      }
    }
  },
  series: [{
    name: 'Pass',
    data: [5, 3, 4, 7, 2]
  }, {
    name: 'Fail',
    data: [2, 2, 3, 2, 1]
  }, {
    name: 'No Run',
    data: [3, 4, 4, 2, 5]
  }]
  });

}
