import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModulewiseComponent } from './modulewise.component';

describe('ModulewiseComponent', () => {
  let component: ModulewiseComponent;
  let fixture: ComponentFixture<ModulewiseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModulewiseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModulewiseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
