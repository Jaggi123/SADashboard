import { Routes,RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { HomeComponent } from './components/home/home.component';
import { BuildexecComponent } from './components/buildexec/buildexec.component';
import { ModulewiseComponent } from './components/modulewise/modulewise.component';
import { ExecComparisonComponent } from './components/exec-comparison/exec-comparison.component';

@NgModule({
    imports: [
        RouterModule.forRoot([
            {path: '', component: HomeComponent},
            {path: 'buildexec', component: BuildexecComponent},
            {path: 'modulewise', component: ModulewiseComponent},
            {path: 'execcomp', component: ExecComparisonComponent}
            ])    
    ],
    exports: [RouterModule]
})
export class AppRoutingModule {}
