import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule }    from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';

import { ChartModule } from 'angular-highcharts';
import { AppComponent } from './app.component';
//import { HomeComponent } from './components/home/home.component';
import { HomeComponent } from './components/home/home.component';
import { BuildexecComponent } from './components/buildexec/buildexec.component';
import { ModulewiseComponent } from './components/modulewise/modulewise.component';
import { ExecComparisonComponent } from './components/exec-comparison/exec-comparison.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BuildexecComponent,
    ModulewiseComponent,
    ExecComparisonComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ChartModule
  ],
  providers: [
      { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {  }